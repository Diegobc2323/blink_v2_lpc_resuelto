#ifndef SVC_SC_H
#define SVC_SC_H

#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>


/**
 * @brief Entra en una secci�n cr�tica y deshabilita las interrupciones.
 *
 * Esta funci�n anida llamadas, manteniendo las interrupciones deshabilitadas
 * hasta que la �ltima llamada a svc_SC_salir_enable_irq se ejecute.
 *
 * @return El contador de nivel de anidamiento de la secci�n cr�tica (para depuraci�n).
 */
uint32_t svc_SC_entrar_disable_irq(void);

/**
 * @brief Sale de una secci�n cr�tica y habilita las interrupciones.
 *
 * Si es la �ltima salida anidada, las interrupciones se habilitan.
 */
void svc_SC_salir_enable_irq(void);


#endif /* SVC_SC_H */
