#include "hal_consumo.h"
 
#include <LPC21xx.H>

/**
 * Inicializa el subsistema de consumo (si procede).
 * Para nRF52 no es necesario configurar nada especial para WFI.
 */
void hal_consumo_iniciar(void){
	/* En esta pr�ctica no es necesario configurar registros de energ�a.
		 Dejamos la funci�n para homogeneizar la API entre plataformas. */
    EXTWAKE = 0x0F;
}

/**
 * Modo "esperar": duerme hasta la pr�xima interrupci�n manteniendo estado
 * (System ON sleep). Sale cuando entra cualquier IRQ habilitada.
 */
void hal_consumo_esperar(void){
	EXTWAKE = 0x0F;

	PCON |= 0X01;
}

/**
 * Modo "dormir": igual que esperar en esta versi�n (WFI).
 * En versiones futuras podr�a a�adir medidas m�s agresivas.
 */
void hal_consumo_dormir(void){
	EXTWAKE = 0x0F;
	PCON |= 0X02;
	switch_to_PLL();
}
